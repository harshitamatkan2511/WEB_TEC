function validateLogin() {
    document.getElementById('loginForm').submit();
}
